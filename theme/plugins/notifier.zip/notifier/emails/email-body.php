<?php
/**
 * Customer new account email
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<p><?php _e('Hola', 'notifier'); ?> <?php echo $author_name; ?></p>

<p><?php printf( __("El teu anunci %s caducará el dia %s.", 'woocommerce'), '<strong>'.esc_html($post_title).'</strong>', '<strong>'.esc_html($expiration_date).'</strong>' ); ?></p>
<p><?php _e("Fes click al següent enllaç per renovar-ho:", 'notifier'); ?></p>
<p><a href="<?php echo $permalink; ?>"><?php echo $permalink; ?></a></p>

<p><?php _e('Gracies! :)', 'notifier'); ?></p>
<p><?php echo $blogname; ?></p>