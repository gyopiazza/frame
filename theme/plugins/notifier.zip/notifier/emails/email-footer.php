<?php
/**
 * Email Footer
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates/Emails
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Load colours
$base = get_option( 'woocommerce_email_base_color' );

$base_lighter_40 = wc_hex_lighter( $base, 40 );

// For gmail compatibility, including CSS styles in head/body are stripped out therefore styles need to be inline. These variables contain rules which are added to the template inline.
$template_footer = "
	border-top:0;
	-webkit-border-radius:6px;
";

$credit = "
	border:0;
	color: $base_lighter_40;
	font-family: Arial;
	font-size:12px;
	line-height:125%;
	text-align:center;
";
?>
															</div>
														</td>
                                                    </tr>
                                                </table>
                                                <!-- End Content -->
                                            </td>
                                        </tr>
                                    </table>
                                    <!-- End Body -->
                                </td>
                            </tr>
                        	<tr>
                            	<td align="center" valign="top">
                                    <!-- Footer -->
                                	<table border="0" cellpadding="10" cellspacing="0" width="600" id="template_footer" style="<?php echo $template_footer; ?>">
                                    	<tr>
                                        	<td valign="top">
                                                <table border="0" cellpadding="10" cellspacing="0" width="100%">
                                                    <tr>
                                                        <td colspan="2" valign="middle" id="credit" style="<?php echo $credit; ?>">
                                                        	<?php echo wpautop( wp_kses_post( wptexturize( apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) ) ) ); ?>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                    <!-- End Footer -->
                                </td>
                            </tr>
                        </table>
                        <p style="color: #999;font-size: 11px; font-family: sans-serif; max-width: 600px; margin: 30px auto;">La información contenida en este mensaje de correo electrónico es confidencial y puede revestir el carácter de reservada. Está destinada exclusivamente a su destinatario. El acceso o uso de este mensaje, por parte de cualquier otra persona que no esté autorizada, pueden ser ilegales. Si no es usted la persona destinataria, le rogamos que proceda a eliminar su contenido. Conforme a la Ley Orgánica 15/1999, de 13 de diciembre, y a la Ley 34/2002 de 12 de Octubre de Servicios de la Sociedad de la Información y de Comercio Electrónico le comunicamos que su dirección de correo electrónico forma parte de nuestro fichero  con el objetivo de poder mantener el contacto con usted y mantener nuestras relaciones comerciales. Si desea oponerse, acceder, cancelar o rectificar sus datos, póngase en contacto con Nuria Piñol PARES I NENS  a través del correo electrónico info@paresinens.cat.</p>
                        <p style="color: #999;font-size: 11px; font-family: sans-serif; max-width: 600px; margin: 30px auto;">La informació continguda en aquest missatge de correu electrònic és confidencial i pot revestir el caràcter de reservada. Està destinada exclusivament al seu destinatari. L'accés o ús d'aquest missatge, per part de qualsevol altra persona que no estigui autoritzada, poden ser il·legals. Si no és vostè la persona destinatària, li preguem que procedeixi a eliminar el seu contingut. Conforme a la Llei Orgànica 15/1999, de 13 de desembre, i a la Llei 34/2002 de 12 d'Octubre de Serveis de la Societat de la Informació i de Comerç Electrònic li comuniquem que la seva adreça de correu electrònic forma part del nostre fitxer amb l'objectiu de poder mantenir el contacte amb vostè i mantenir les nostres relacions comercials. Si desitja oposar-se, accedir, cancel·lar o rectificar les seves dades, posi's en contacte amb Nuria Piñol PARES I NENS a través del correu electrònic info@paresinens.cat</p>
                    </td>
                </tr>
            </table>
        </div>
    </body>
</html>