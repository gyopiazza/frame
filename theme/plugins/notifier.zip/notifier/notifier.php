<?php

/*
Plugin Name: Notifier
Plugin URI: 
Description: Send automatic email notifications to users based on configurable rules like new posts, new comments, post expiration, etc. It works best when attached to a cron job.
Version: 1.0
Author: Giordano Piazza
Author URI: http://giordanopiazza.com
Author Email: gyopiazza@gmail.com
License:

  Copyright 2014 Giordano Piazza (giordanopiazza.com)

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License, version 2, as 
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
  
*/

// Prevent direct access to this file
if (!class_exists('WP')) { header('Status: 403 Forbidden'); header('HTTP/1.1 403 Forbidden'); exit; }


// Set the daily cron job
function notifier_activation()
{
  // hourly twicedaily daily
  wp_schedule_event(time(), 'hourly', 'notifier_check_cron');
}

register_activation_hook(__FILE__, 'notifier_activation');


add_action( 'notifier_check_cron', 'notifier_check' );



// Check the registered conditions and send emails if necessary
function notifier_check()
{
  // Get today's date for comparison
  $today = time();

  // Get posts expiring in 3 days
  $start = $today;
  $end = strtotime("+3 days", $today);

  $args = array(
    'post_type' => 'classifieds',
    'posts_per_page' => -1,
    'meta_key' => '_cred_post_expiration_time',
    'meta_compare' => 'BETWEEN',
    'meta_value' => array($start, $end),
    'post_status' => 'publish'
  );

  $query = new WP_Query($args);

  $results = array();

  while($query->have_posts()): $query->the_post();
    
    $post_id = get_the_ID();

    $notification_sent = get_post_meta($post_id, 'notification_sent', true);

    if (empty($notification_sent))
    {
      global $post;
      $expiration_date = get_post_meta($post_id, '_cred_post_expiration_time', true);

      $results[] = array(
        'id' => $post_id,
        'author_id' => $post->post_author,
        'author_name' => get_the_author(),
        'author_email' => get_the_author_meta('user_email', get_the_author()),
        'title' => get_the_title(),
        'expiration_timestamp' => $expiration_date,
        'expiration_date' => date('d-m-Y H:i', $expiration_date),
        'notification_sent' => $notification_sent,
        'permalink' => home_url('/modifica-anunci/').'?renew=1&edit='.$post_id
      );

      $result = notifier_send_email(
        get_the_author(),
        get_the_author_meta('user_email', $post->post_author),
        get_the_title(),
        date('d-m-Y H:i',$expiration_date),
        home_url('/modifica-anunci/').'?renew=1&edit='.$post_id
      );

      // Mark the post to avoid multiple notifications
      if ($result)
        $meta = update_post_meta($post_id, 'notification_sent', true);

      t_log('--------------------------');
      t_log(var_export(get_the_author_meta('user_email', $post->post_author), true));
      t_log('post_id: ' . $post_id);
      t_log('meta: ' . $meta);
    }

    // $start_date = date('Y-m-d', get_field('event_date', get_the_ID()));
    // $end_date = (get_field('event_date_end', get_the_ID())) ? get_field('event_date_end', get_the_ID()) : $start_date;
    
  endwhile;
  
  wp_reset_postdata();

  // if (!is_admin())
    // d($results);
}

// add_action('init', 'notifier_check');



function notifier_send_email($author_name, $author_email, $post_title, $expiration_date, $permalink)
{
  global $wpdb, $wp_version;
  $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
  // $headers = "Content-Type: text/htmlrn";
  $headers = array('From: '.$blogname.' <noreply@paresinens.cat>', 'Content-Type: text/html; charset=UTF-8');
  $attachments = "";

  $subject = __("El teu anunci está al punt de caducar", 'notifier');
  
  // El teu anunci %%POST_TITLE%% caducará el dia %%EXPIRATION_DATE%%.

  // Get the email HTML
  ob_start();
  extract(array(
    'email_heading' => $subject,
    'blogname' => $blogname,
    'author_name' => $author_name,
    'post_title' => $post_title,
    'expiration_date' => $expiration_date,
    'home_url' => home_url('/'),
    'post_link' => $permalink,
  ));
  include "emails/email-header.php";
  include "emails/email-body.php";
  include "emails/email-footer.php";
  $message = ob_get_contents();
  ob_end_clean();

  add_filter('wp_mail_content_type', 'notifier_set_html_content_type');
  $email = wp_mail($author_email, $subject, $message, $headers);
  // $email = true;
  remove_filter('wp_mail_content_type', 'notifier_set_html_content_type');

  // $test = array(
  //   $author_email,
  //   $subject,
  //   $message,
  //   $headers
  // );

  // t_log(var_export($author_email, true));

  return $email;
}

function notifier_set_html_content_type()
{
  return 'text/html';
}

/**
 * Enqueue scripts and styles
 */
// function notifier_scripts()
// {
//   wp_enqueue_script('notifier', plugins_url( 'anystretch.js', __FILE__ ), array('jquery'), '1');
// }

// add_action( 'wp_enqueue_scripts', 'notifier_scripts' );



